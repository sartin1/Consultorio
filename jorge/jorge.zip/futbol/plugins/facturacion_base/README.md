# facturacion_base
Plugin para FacturaScripts con las funciones básicas de facturación y contabilidad.

https://www.facturascripts.com
<h1>Plugin "Backups"</h1>

<strong>Ubicación del plugin:</strong> facturascripts/plugins/backups

<br>

<strong>Descripción</strong>

Plugin para añadir soporte para backups de la base de datos de FacturaScripts

<br>

<strong>Características:</strong>

<ul>
   <li>Permite importar/exportar desde MySQL</li>
   <li>Permite importar/exportar desde PostgreSQL</li>
</ul>

<br>

<strong>Sugerencias en consideración:</strong>

<ul>
   <li></li>
</ul>

<br>

<strong>Apoya el plugin:</strong>

Puedes apoyar el desarrollo del plugin sugiriendo y enviando cambios.

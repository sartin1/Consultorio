<h1>Plugin "Presupuestos y pedidos"</h1>
Plugin que añade soporte de presupuestos y pedidos a FacturaScripts.
https://www.facturascripts.com

<strong>Características:</strong>
<ul>
   <li>Soporte para presupuestos que se pueden aprobar en pedidos.</li>
   <li>Soporte para pedidos que se pueden aprobar en albaranes.</li>
   <li>Presupuestos con tiempo de validez. No se bloquean, solo se indica.</li>
   <li>Presupuestos y pedidos con control de estado rechazado.</li>
</ul>